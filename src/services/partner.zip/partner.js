import { api } from "./api";

export const submitOnboardingStep = async (step, data) => {
  await new Promise((r) => setTimeout(r, 400));

  return {
    success: true,
    step,
    data,
  };
};

export const getApplicationStatus = async () => {
  await new Promise((r) => setTimeout(r, 400));

  return {
    status: "pending",
    submittedOn: new Date().toISOString(),
  };
};

export const getDutyStatus = async () => {
  return await api.get("/partner/duty-status");
};

export const setDutyOn = async () => {
  return await api.patch("/partner/duty-on", {});
};

export const setDutyOff = async () => {
  return await api.patch("/partner/duty-off", {});
};

export const uploadKyc = async ({
  selfie,
  nationalId,
  astrologyCertificate,
  addressProof,
}) => {
  const formData = new FormData();

  if (selfie) formData.append("selfie", selfie);
  if (nationalId) formData.append("nationalId", nationalId);
  if (astrologyCertificate) {
    formData.append("astrologyCertificate", astrologyCertificate);
  }
  if (addressProof) formData.append("addressProof", addressProof);

  return await api.post("/partner/kyc/upload", formData);
};

export const getKycStatus = async () => {
  return await api.get("/partner/kyc/status");
};