import { createContext, useState, useEffect } from "react";
import { storage } from "../utils/storage";

import {
  sendOtp,
  verifyOtp as firebaseVerifyOtp,
  clearAuthSession,
} from "../services/authService";

export const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(() => storage.get("user"));
  const [loading, setLoading] = useState(false);
  const [pendingPhone, setPendingPhone] = useState("");

  useEffect(() => {
    if (user) {
      storage.set("user", user);
    } else {
      storage.remove("user");
    }
  }, [user]);

  // Send Firebase OTP
  const login = async ({ phone }) => {
    setLoading(true);

    try {
      const result = await sendOtp(phone);

      setPendingPhone(result.phone);

      return result;
    } catch (error) {
      console.error("Login OTP Error:", error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  // Verify Firebase OTP
  const verifyOtp = async (otp) => {
    setLoading(true);

    try {
     const result = await firebaseVerifyOtp(otp);

      const firebaseUser = result.user;

      const newUser = {
        id: firebaseUser.uid,
        uid: firebaseUser.uid,
        phone: firebaseUser.phoneNumber || pendingPhone,
        name: "New Partner",
        applicationStatus: "pending",
      };

      setUser(newUser);

      return newUser;
    } catch (error) {
      console.error("Verify OTP Error:", error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    clearAuthSession();
    setUser(null);
    setPendingPhone("");
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        setUser,
        loading,
        login,
        verifyOtp,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};